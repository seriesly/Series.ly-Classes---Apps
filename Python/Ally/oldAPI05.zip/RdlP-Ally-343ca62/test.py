# -*- coding: utf-8 -*-

import Ally

usuario = "Prueba"
contrasena = "contrasena"
id_aplicacion = "111111111111"
key_aplicacion = "dfdgdgbfbedwe4rfgrg"

Api = Ally.Ally(usuario,contrasena,id_aplicacion,key_aplicacion)
usuario = Api.user_info()
print usuario
print Api.user_misSeries()
print Api.user_misPelis()

print Api.buscar("Como conocí a vuestra madre", "serie")
print Api.ficha_peli("UC2H5XKEFT") #EL idFilm corresponde a Harry Potter y el Caliz de Fuego
print Api.ficha_serie("TKXF3CYTT2") #El idSerie corresponde a The Walking Dead
print Api.ficha_serie("TKXF3CYTT2")['title'] #El idSerie corresponde a The Walking Dead
print Api.caps_serie("5HHY9YEFN7") #El idSerie corresponde a comoconoci a vuestra madre
print Api.links_cap("44IzID") #El idCap es del capitulo 1x01 de como conocí a vuestra madre)

print Api.cargar_enlace(Api.ficha_peli("UC2H5XKEFT"), 0)

#print Api.cambiar_estado("UC2H5XKEFT", 1, 3) #El id es el de harry potter, no va)
#print Api.marcar_episodio("44IzID", "0")
print Api.puntuar("UC2H5XKEFT", "1", "5")
print Api.tops("1") #Series más votadas
print Api.mostrar_comentarios(usuario['friends'][0]['uid'], "user" )
#print Api.nuevo_comentario("Prueba", usuario['friends'][0]['uid'], 'user' )

print usuario['friends'][0]
print usuario['friends'][0]['nick']